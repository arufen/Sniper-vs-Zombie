﻿//---------------------------------------------------------------------------
//!	@file	TutorialX_Camera.h
//! @brief	TutorialX_Camera
//---------------------------------------------------------------------------
#include <System/Scene.h>

namespace SniperVsZombie
{
	USING_PTR(Camera);
	class Camera : public Object
	{
	public:
		BP_OBJECT_DECL(Camera, "SniperVsZombie::Camera");

		void Shoot();

		//! @brief 初期化
		//! @return 初期化終了
		bool Init() override;
		void Update() override;
		void Exit() override;

	private:
		float shootIntervalTime = 1.0f;
		float shootCurrentTime	= shootIntervalTime;

		int shootSoundHandle_ = -1;	   //!< sniper shot SFX, loaded in Init()
	};
}	 // namespace SniperVsZombie
